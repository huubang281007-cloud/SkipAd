package com.example.skipad

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SkipAdService : AccessibilityService() {

    private val labels = listOf("Skip ad", "Skip ads", "Skip", "Bỏ qua quảng cáo", "Bỏ qua")
    private val skipViewId = "com.google.android.youtube:id/skip_ad_button"
    private var lastClick = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.packageName != "com.google.android.youtube") return

        val prefs = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, true)) return

        val now = System.currentTimeMillis()
        if (now - lastClick < 1500) return

        val root = rootInActiveWindow ?: return
        val target = findSkipButton(root) ?: return

        val clickable = generateSequence(target) { it.parent }
            .take(4)
            .firstOrNull { it.isClickable } ?: return

        if (clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            lastClick = now
            prefs.edit()
                .putInt(MainActivity.KEY_COUNT, prefs.getInt(MainActivity.KEY_COUNT, 0) + 1)
                .apply()
        }
    }

    private fun findSkipButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByViewId(skipViewId).firstOrNull()?.let { return it }
        for (label in labels) {
            root.findAccessibilityNodeInfosByText(label).firstOrNull()?.let { return it }
        }
        return null
    }

    override fun onInterrupt() {}
}
