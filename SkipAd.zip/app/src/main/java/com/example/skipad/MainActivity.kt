package com.example.skipad

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var counter: TextView
    private lateinit var enableSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        counter = findViewById(R.id.counter)
        enableSwitch = findViewById(R.id.enableSwitch)

        enableSwitch.isChecked = prefs().getBoolean(KEY_ENABLED, true)
        enableSwitch.setOnCheckedChangeListener { _, checked ->
            prefs().edit().putBoolean(KEY_ENABLED, checked).apply()
        }

        findViewById<Button>(R.id.openSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.setText(
            if (isServiceEnabled()) R.string.status_service_on else R.string.status_service_off
        )
        counter.text = getString(R.string.counter, prefs().getInt(KEY_COUNT, 0))
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = "$packageName/${SkipAdService::class.java.name}"
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    companion object {
        const val PREFS = "skipad"
        const val KEY_ENABLED = "enabled"
        const val KEY_COUNT = "count"
    }
}
